CREATE DATABASE IF NOT EXISTS restoran;
USE restoran;

CREATE TABLE admin (
    id_admin INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE produk (
    id_produk INT AUTO_INCREMENT PRIMARY KEY,
    nama_produk VARCHAR(100) NOT NULL,
    harga DECIMAL(10,2) NOT NULL,
    deskripsi TEXT,
    kategori VARCHAR(50),
    gambar VARCHAR(255)
);

CREATE TABLE keranjang (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_produk INT,
    jumlah INT,
    FOREIGN KEY (id_produk) REFERENCES produk(id_produk)
);

CREATE TABLE transaksi (
    id_transaksi INT AUTO_INCREMENT PRIMARY KEY,
    total DECIMAL(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE transaksi_detail (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaksi_id INT,
    id_produk INT,
    jumlah INT,
    FOREIGN KEY (transaksi_id) REFERENCES transaksi(id_transaksi),
    FOREIGN KEY (id_produk) REFERENCES produk(id_produk)
);

INSERT INTO admin (username, password) VALUES ('admin', '$2y$10$wHpllgk8UHTPfqOUhcWc0uDPEU0Ql4/Of4zRvMwUIe77Cj7rC0V9a');
