<?php
session_start();
include 'includes/config.php';
include 'includes/auth.php';

if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = $_POST['id_produk'];
    $qty = $_POST['jumlah'];
    $_SESSION['cart'][$id] = ['jumlah' => $qty];
}

echo "<h2>Keranjang</h2>";
$total = 0;
foreach ($_SESSION['cart'] as $id => $item) {
    $stmt = $pdo->prepare("SELECT * FROM produk WHERE id_produk = ?");
    $stmt->execute([$id]);
    $produk = $stmt->fetch();
    $subtotal = $produk['harga'] * $item['jumlah'];
    echo "{$produk['nama_produk']} - {$item['jumlah']} x Rp {$produk['harga']} = Rp $subtotal<br>";
    $total += $subtotal;
}
echo "<p>Total: Rp $total</p>";
echo '<a href="checkout.php">Checkout</a>';
